import random
import math


GAME_RULE = 'What number is missing in the progression?'


step = random.randint(1, 10)
start_collection = random.randint(0, 50)


def ask_question_get_answer():
    collection = list(range(start_collection, start_collection + step * 10, step))
    correct_answer = collection[step]
    question = collection[step] = '..'
    return question, correct_answer
